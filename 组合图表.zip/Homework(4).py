# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 16:02:55 2021

@author: Zhang_Weihan
"""

"""
--------------------------全球总确诊病例数对比统计图-----------------------------
    该图意在对比2020年7月3日全球总确诊新冠肺炎病例数与2021年3月3日全球总确诊新冠肺炎病\
例数，通过可视化的手段展现新冠肺炎疫情在过去半年内的消涨情况。
    数据来源：https://ourworldindata.org/coronavirus。
-------------------------------------------------------------------------------

"""
#加载pyecharts
from pyecharts.charts import Bar
from pyecharts import options as opts
import pandas as pd#加载pandas，方便读取和处理数据
import numpy as np#加载numpy，方便处理数据

#准备数据
dataset=pd.read_csv('./data/owid-covid-data.csv')#读取原始数据集

dataset['date']=pd.to_datetime(dataset['date'])#按照日期对数据集进行排序，并选取'2020-07-03'的数据
df_1 = dataset.sort_values(by=['date'], ascending=False) 
map_df_1=df_1[df_1['date']=='2020-07-03']
map_df_1.reset_index(drop=True, inplace=True)

dataset['date']=pd.to_datetime(dataset['date'])#按照日期对数据集进行排序，并选取'2021-03-03'的数据
df_2 = dataset.sort_values(by=['date'], ascending=False) 
map_df_2=df_2[df_2['date']=='2021-03-03']
map_df_2.reset_index(drop=True, inplace=True)

location=list(map_df_1['location'])#读取国家/地区数据，并创建列表

totalcases_1=list(np.log10(map_df_1['total_cases']))#从'2020-07-03'的数据中选取总病例数，并创建列表
list1 = [[location[i],totalcases_1[i]] for i in range(len(location))] 

totalcases_2=list(np.log(map_df_2['total_cases']))#再从'2021-03-03'的数据中选取总病例数，并创建列表
list2 = [[location[i],totalcases_2[i]] for i in range(len(location))] 

#创建柱状图
bar = (
        Bar()
        
        .add_xaxis(location)#横坐标为各个国家/地区
        
        .add_yaxis("2020年7月3日各国总确诊病例数", totalcases_1,#第一个纵坐标轴为"2020年7月3日各国病例数"
         label_opts = opts.LabelOpts(is_show=False))
        
        .add_yaxis("2021年3月3日各国总确诊病例数", totalcases_2,#第二个坐标轴为"2021年3月3日各国病例数"
         label_opts = opts.LabelOpts(is_show=False))#不显示数字标签
        .set_global_opts(
            title_opts=opts.TitleOpts(title="全球总确诊病例数对比统计图"),#设置标题
            datazoom_opts=[opts.DataZoomOpts()],
            yaxis_opts=opts.AxisOpts(name='病例数（人，取log10）'#设置y坐标轴名称
                                     ,name_location='middle' #坐标轴名字所在的位置
                                     ,name_gap=25)#坐标轴名字与坐标轴之间的距离)
        
    )
   
)

#保存输出文件
bar.render("./output/组合图表.html")