# -*- coding: utf-8 -*-
"""
Created on Sun Apr  4 15:21:41 2021

@author: Zhang_Weihan
"""

"""
----------------------------全球疫情病例数统计图---------------------------------
    该图意在反映2020年7月3日全球新冠肺炎疫情总确诊病例数的实时统计结果，并采用分层设色\
的方式对其进行了可视化处理。
   数据来源：https://ourworldindata.org/coronavirus。
-------------------------------------------------------------------------------
"""

#加载map
from pyecharts.charts import Map
from pyecharts import options as opts
import pandas as pd#加载pandas，方便读取和处理数据

#准备数据
dataset=pd.read_csv('./data/owid-covid-data.csv')#读取原始数据集

dataset['date']=pd.to_datetime(dataset['date'])#按照日期对数据集进行排序，并选取'2020-07-03'的数据
df = dataset.sort_values(by=['date'], ascending=False) 
map_df=df[df['date']=='2020-07-03']
map_df.reset_index(drop=True, inplace=True)

country=list(map_df['location'])#再从'2020-07-03'的数据中选取1)国家/地区；2)总病例数，并创建列表
totalcases=list(map_df['total_cases'])
list1 = [[country[i],totalcases[i]] for i in range(len(country))] 

#创建map
c = (
     Map()
     
    .add('总确诊病例',#设置描点名称
 list1,
 maptype='world',#设置为世界地图
 is_map_symbol_show=False)#不显示描点
    
.set_series_opts(label_opts=opts.LabelOpts(is_show=False))#不显示标签
 
.set_global_opts(
visualmap_opts=opts.VisualMapOpts(max_=1100000,is_piecewise=True,pieces=[
 #设置分层标准，每一层有不同的颜色标记，其中数据缺失的国家/地区为灰色
 {'min': 500000},
 {'min': 200000, 'max': 499999},
 {'min': 100000, 'max': 199999},
 {'min': 50000, 'max': 99999},
 {'min': 10000, 'max': 49999},
 {'max': 9999},]),
 title_opts=opts.TitleOpts(
 title='新冠肺炎全球总病例数',#设置主标题
 subtitle='截止日期：2020年7月3日',#设置副标题
 pos_left='center',#设置标题的水平位置
 padding=10,#设置标题的垂直位置
 item_gap=1,#设置主副标题的间距
 #设置标题文字的字体，颜色等属性
 title_textstyle_opts= opts.TextStyleOpts(color='darkblue',
 font_weight='bold',
 font_family='Courier New',
 font_size=30), 
 subtitle_textstyle_opts= opts.TextStyleOpts(color='grey',
 font_weight='bold',
 font_family='Courier New',
 font_size=13)), 
 legend_opts=opts.LegendOpts(is_show=False))#不显示文本标签

#保存输出文件
.render('./output/全球疫情病例数统计图_map.html')
)
