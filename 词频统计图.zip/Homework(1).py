# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 08:42:10 2021

@author: Zhang_Weihan
"""

"""
------------------------------词频统计图----------------------------------------
    词频统计可视化将采用三种不同类型的图表，包括：
    1)柱状图；
    2)词云：
    3)关系图（其实是图论里的'Graph'）。
-------------------------------------------------------------------------------
"""

"""
柱状图
"""

#加载matplotlib
import matplotlib.pyplot as plt

#指定所用中文的字体
import os
if os.name == "nt":#适用于Windows系统 
    plt.rcParams['font.sans-serif'] = ['SimHei']#设置字体
else: 
    plt.rcParams["font.family"] = 'Arial Unicode MS'  
plt.rcParams['axes.unicode_minus'] = False  

#读取文件
src_filename = './data/《自杀论》-关键词词频.csv'

src_file = open(src_filename, 'r')
line_list = src_file.readlines()#生成初始列表
src_file.close()#关闭文件
print(line_list)

#生成横纵坐标数据
word_list = []#生成空列表-横轴数据
cnt_list = []#生成空列表-纵轴数据

del line_list[0]#删除标题行 

for line in line_list:
    line = line.replace('\n', '')#删除中间空格
    word_cnt = line.split(',')#用逗号将词和数据分隔开
    word_list.append(word_cnt[0])#词放入横轴列表
    cnt_list.append(int(word_cnt[1]))#数据放入纵轴列表
print(word_list)
print(cnt_list)

#设置柱状图横纵坐标
plt.bar(word_list, cnt_list)

#设置横纵坐标的刻度  
n = len(cnt_list)
plt.xticks(range(n), word_list[0:n])
plt.yticks(range(0,max(cnt_list)+10,500))#以500为单位，图较为清晰简明

#设置图的标题，横纵坐标的名称
plt.title('《自杀论》关键词柱状图') 
plt.xlabel('关键词')
plt.ylabel('出现次数') 

#保存统计图
plt.savefig('./output/《自杀论》关键词词频统计图(1).png')



"""
词云
"""

#加载词云库
from pyecharts import options as opts
from pyecharts.charts import WordCloud

#读取文件
src_filename = './data/《自杀论》-关键词词频.csv'

src_file = open(src_filename, 'r')
line_list = src_file.readlines()#生成初始列表  
src_file.close()#关闭文件
print(line_list)

#生成词频列表
wordfreq_list = []#生成空列表  
for line in line_list:
    line = line.strip()#删去两端空格  
    line_split = line.split(',')#分割列表中的元素
    wordfreq_list.append((line_split[0],line_split[1]))#向词频列表中添加元素
print(wordfreq_list)

del wordfreq_list[0]#删去标题 

#生成词云
cloud = WordCloud()

#设置词云图
cloud.add('', 
          wordfreq_list[:], 
          shape='circle',#设置形状
          is_draw_out_of_bound=False,#不允许超出边界 
          word_size_range=[15, 50],#设置字体大小范围 
          textstyle_opts=opts.TextStyleOpts(font_family="微软雅黑"),#设置字体
          )

cloud.set_global_opts(title_opts=opts.TitleOpts(title="《自杀论》关键词词云"))#设置标题

#保存输出文件
out_filename = './output/《自杀论》关键词词频统计图(2).html'
cloud.render(out_filename)





"""
--------------------------------关系图------------------------------------------
   该图意在表现关键词之间的关系，并将各个关键词的重要性依据频数大小加以可视化处理。
   作图的基本步骤为：
   1)对关键词的原始数据进行加工，生成node作为图的基本要素；
   2)生成link，将node相连以表现关键词之间的关系；
   3)组合node和link，生成Graph。
   P.S.将关键词数据加工成node是该程序中最复杂的部分，因为pyecharts中对于该图的要求是\
node数据必须为一个包含多个字典的列表，其中每个字典中包含两个item，分别为'name'-词汇键\
值对和'symbolSize'-频数键值对。
-------------------------------------------------------------------------------
"""

#加载pyecharts和Graph
from pyecharts import options as opts
from pyecharts.charts import Graph

#读取文件
src_filename = './data/《自杀论》-关键词词频.csv'

src_file = open(src_filename, 'r')
line_list = src_file.readlines()#生成初始列表
src_file.close()#关闭文件
print(line_list)

#将原始数据进行处理，得到node数据
word_list = []#生成第一个词汇列表
cnt_list = []#生成第一个频数列表

del line_list[0]#删除标题行 

for line in line_list:#遍历初始列表
    line = line.replace('\n', '')#去掉中间空格
    word_cnt = line.split(',')#分割列表元素
    word_list.append(word_cnt[0])#将初始列表里的第一个元素赋给第一个词汇列表
    cnt_list.append(int(word_cnt[1])/100)#将初始列表里的第二个元素除以100（因为某些词汇的频数太大，若保留原值会充斥屏幕，影响观感）后赋给第一个频数列表
print(word_list)
print(cnt_list)

name_list = ['name']*len(word_list)#生成'name'列表，作为词汇字典的键
symbolSize_list = ['symbolSize']*len(cnt_list)#生成'symbolSize'列表，作为频数字典的键

c_word_list = list(tuple({a:b}for a,b in zip(name_list,word_list)))#生成第二个词汇列表(先将name_list和word_list的元素两两组成多个字典放入元组，再转换成列表)，列表中的每一个元素都是'name'列表（作为字典的键）和第一个词汇列表（作为字典的值）中的每一个元素两两组成的词汇字典
print(c_word_list)
c_cnt_list = list(tuple({a:b} for a,b in zip(symbolSize_list,cnt_list)))#生成第二个频数列表(先将symbolSize_list和cnt_list的元素两两组成多个字典放入元组，再转换成列表)，列表中的每一个元素都是'symbolSize'列表（作为字典的键）和第一个频数列表（作为字典的值）中的每一个元素两两组成的频数字典
print(c_cnt_list)

for i in range(len(c_word_list)):#遍历列表
    c_word_list[i].update(c_cnt_list[i])#将两个列表合并

nodes_list = []#生成node列表
nodes_list = c_word_list#得到node列表，其中的每一个node都是由将前两个列表中的字典两两相加而得，也就是说node列表中的每一个元素都是一个有着两个'item'（一个是'name'+词汇；另一个是'symbolSize'+频数）的字典
print(nodes_list)

#生成link
links = []#生成link列表
for i in nodes_list:#遍历node列表
    for j in nodes_list:
        links.append({"source": i.get("name"), "target": j.get("name")})#将node两两相接（这里其实是有问题的，稍后解释）
        
#生成Graph        
c = (
    Graph()
    .add("", nodes_list, links, repulsion=8000)
    .set_global_opts(title_opts=opts.TitleOpts(title="《自杀论》关键词关系图"))#设置标题
    .render("./output/《自杀论》关键词词频统计图(3).html")#保存输出文件
)

"""
--------------------------------遗憾之处----------------------------------------
    由于本人技术欠缺，该图存在如下不足：
    1)虽然节点的大小因频数大小而不同（因而是一个'Weighted Graph'），但没有显示每个node\
对应的频数；
    2)画出来的是一个'Complete Graph'，然而实际上关键词并非都是两两关联的，所以理想的关\
系图应该是一个'Incomplete Graph'；
    3)点开时画面会有些混乱。
-------------------------------------------------------------------------------
"""
    



