# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 19:24:45 2021

@author: Zhang_Weihan
"""

"""
------------------------------小张的美国之旅------------------------------------
    故事背景：
    在不久的将来，百京带学底层菜狗小张在申请季中被“全聚德”了——上帝给小张关上了窗户，顺\
便也把门带上了——即使现实是如此地惨淡，但是对政治科学的研究充满着热情和向往的小张仍然决\
定要去世界政治科学的学术高地——美利坚政治科学十大名校去瞻仰一番。于是，申请季一结束他就\
动身前往北美，从寒冷的新英格兰出发，游历中大西洋沿岸，来到温暖的美国南部，又坐飞机抵达\
五大湖区，最终在充满阳光和沙滩的加州结束旅行。
    说明：
    此地理连线图就是对小张（脑海中）的美国之旅的行程的描绘。图上的点代表大学，点的颜色\
代表该大学的政治科学学科在2021 U.S.News Rankings里的排名，颜色越偏红则排名越高（其实\
都是top10）；图上的连线则代表小张的行程。
-------------------------------------------------------------------------------
"""

#加载Geo
from pyecharts import options as opts
from pyecharts.charts import Geo
from pyecharts.datasets import register_url
from pyecharts.globals import ChartType, SymbolType

register_url("https://echarts-maps.github.io/echarts-countries-js/")

#设定区域
site_name = "美国" 

#运用链式调用设定geo 
geo = (
    Geo()
    #根据经纬度在地图库中添加坐标点
    .add_coordinate(
    name="Stanford",
    longitude=-122.17, 
    latitude=37.43
    
    )

.add_coordinate(
    name="Harvard",
    longitude=-71.12, 
    latitude=42.38
    
    )

.add_coordinate(
    name="Princeton",
    longitude=-74.67, 
    latitude=40.36
    
    )

.add_coordinate(
    name="U.C. Berkeley",
    longitude=-122.26, 
    latitude=37.88
    
    )

.add_coordinate(
    name="U.M. Ann Arbor",
    longitude=-83.74, 
    latitude=42.28
    
    )

.add_coordinate(
    name="Yale",
    longitude=-72.92, 
    latitude=41.32
    
    )

.add_coordinate(
    name="M.I.T.",
    longitude=-71.10, 
    latitude=42.36
    
    )

.add_coordinate(
    name="Columbia",
    longitude=-73.96, 
    latitude=40.81
    
    )

.add_coordinate(
    name="U.C. San Diego",
    longitude=-117.23, 
    latitude=32.88
    
    )

.add_coordinate(
    name="Duke",
    longitude=-78.94, 
    latitude=36.00
    
    )

.add_coordinate(
    name="U of Chicago",
    longitude=-87.60, 
    latitude=41.79
    
    )

#在地图上添加坐标点
.add("",
        [("Stanford",100),("Harvard",90),("Princeton",90),("U.C. Berkeley",80),
         ("U.M. Ann Arbor",80),("Yale",70),("M.I.T.",60),("Columbia",50),
         ("U.C. San Diego",50),("Duke",40),("U of Chicago",40)], 
        type_=ChartType.EFFECT_SCATTER#设置为“点”
        )
    .add_schema(maptype=site_name)#设定区域为“美国”
    .set_global_opts(title_opts=opts.TitleOpts(title=site_name))
    
.add(
        "American Airlines",#设定航空公司名
        [("Harvard", "M.I.T."), ("M.I.T", "Yale"), ("Yale", "Columbia"),
         ("Columbia", "Princeton"), ("Princeton", "Duke"),("Duke","U.M. Ann Arbor"),
         ("U.M. Ann Arbor","U of Chicago"),("U of Chicago","U.C. Berkeley"),
         ("U.C. Berkeley","Stanford"),("Stanford","U.C. San Diego")],
         #连线方向参数是由元组项组成的列表
        type_=ChartType.LINES,
        effect_opts=opts.EffectOpts(
            symbol=SymbolType.ARROW, symbol_size=6, color="white"#设置箭头
        ),
        linestyle_opts=opts.LineStyleOpts(curve=0.2),#设置连线的弯曲程度
)
 
.set_series_opts(label_opts=opts.LabelOpts(is_show=False))#关闭连线标签
.set_global_opts(visualmap_opts=opts.VisualMapOpts(max_=100),#设置颜色显示的最大值
                    title_opts=opts.TitleOpts(title="小张的美国之旅"))#设置标题

#保存输出文件
.render('./output/polisci_top10_universities.html')
)  