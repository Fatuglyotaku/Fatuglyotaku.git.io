# -*- coding: utf-8 -*-
"""
Created on Tue Mar 16 20:24:55 2021

@author: Zhang_Weihan
"""

"""
《自杀论》关键词词频统计
"""

"""
--------------------------------文本词汇统计------------------------------------
    文本词汇统计部分将对原始文本进行处理，内容包括：
    1）分词；
    2）统计有效词汇词数；
    3）按词频高低对词汇进行排序；
    4）按照特定规则统计部分词汇的词频。
-------------------------------------------------------------------------------
"""
         
#加载中文分词库
import jieba

#命名文件
txt_filename = './data/《自杀论》.txt'#待分析文本名
result_filename = './output/《自杀论》-关键词词频.csv'#结果文件名

#不想统计的词
ignore_list = ['能够', '因为', '这些', '而且', '正是', '可以', '这个', '不仅', '不会'\
, '各种', '如果', '因此', '那么', '而是', '起来', '没有', '应该', '这种', '可能', '只有'\
, '及其', '这是', '所以', '不能', '才能', '所谓', '比较', '某些', '叫做', '但是', '十分'\
, '任何', '这样', '完全', '实在', '除非', '不同', '因而', '怎么', '其他', '非常', '除了'\
, '大概', '东西', '况且', '然而', '难道', '一旦', '肯定', '就是', '说明', '这种', '如何'\
, '什么', '仅仅', '并非', '\n', '我们', '一种', '他们', '一个', '不是', '人数', '原因'\
, '情况', '影响', '人们', '同样', '增加', '某种', '产生']
    
#读取文本
txt_file = open(txt_filename, 'r', encoding='utf-8')
content = txt_file.read()
txt_file.close

#分词
word_list = jieba.lcut(content)

#调整词库
jieba.add_word('利己主义的自杀') # 添加指定词
jieba.add_word('利他主义的自杀')
jieba.add_word('反常的自杀')

# 用字典统计每个词的出现次数
word_dict = {}
for w in word_list:
    # 跳过单字
    if len(w) == 1:
        continue    
    # 跳过不想统计的词 
    if w in ignore_list:
        continue
    #名词合并
    if w == '道德观念':
        w = '道德'
    elif w == '社会形态':
        w = '社会'
    elif w == '集体':
        w = '社会'
    elif w == '群体':
        w = '社会'
    elif w == '利己主义':
        w = '利己主义的自杀'
    elif w == '利他主义':
        w = '利他主义的自杀'
    elif w == '反常':
        w = '反常的自杀'
    else:
        pass
    
 # 已在字典中的词，将出现次数增加1；否则，添加进字典，次数记为1
    if w in word_dict.keys():
        word_dict[w] = word_dict[w] + 1
    else:
        word_dict[w] = 1
        
# 把字典转成列表，并按原先“键值对”中的“值”从大到小排序
items_list = list(word_dict.items())
items_list.sort(key=lambda x:x[1], reverse=True)

#有效词数统计
total_num = len(items_list)
print('经统计，《自杀论》中共有' + str(total_num) + '个不同的词。')
print()

"""
----------------------------------关键词展示------------------------------------
    关键词展示部分由一系列问题构成，通过回答“是”或“否”，读者可以选择是否查看某一关键词\
 的统计数据。
    1）若读者回答“是”则显示当前关键词的词频统计数据并进入下一个问题，下一个问题中包含的\
关键词可能与前一个关键词有某种程度的联系；
    2）若读者回答“否”则直接进入下一个问题，下一个问题中包含的关键词与前一个关键词没有联\
系；
    3）无论读者在过程中如何选择，程序最终呈现的将是本书出现频率前十的关键词及其频数；
    4）若读者没有按照要求回答“是”或“否”，程序会显示错误并退出。
-------------------------------------------------------------------------------
"""

print('《自杀论》是历史上第一部运用实证主义方法论讨论自杀问题的社会学著作。')#著作内容简介（一）
print()

#关键词展示
question1 = input('您想知道本书中一共出现了多少次“自杀”吗？请输入“是”或“否”：')#问题（一） 
if question1 == '是':#一级分支：是
   print()
   print('经统计,《自杀论》中一共出现了' + str(word_dict['自杀']) + '次“自杀”' +'。')
   print()
   
   print('《自杀论》将自杀按其发生原因分为三种类型。')#著作内容简介（二）
   print()
   
   question2 = input('您想知道本书中三种自杀类型分别出现了多少次吗？请输入“是”或“否”：')#问题（二）
   if question2 == '是':#二级分支：是
      print()
      print('经统计,《自杀论》中一共出现了' + str(word_dict['利己主义的自杀']) + '次“利\
己主义的自杀”'+ '；' + str(word_dict['利他主义的自杀']) + '次“利他主义的自杀”' + '；'\
+str(word_dict['反常的自杀'])+ '次“反常的自杀”'+'。')
      print()
      
      print('《自杀论》着重讨论了自杀的社会性，即“自杀作为一种社会现象”。')#著作内容简介（三）
      print()
      
      question3 = input('您想知道本书一共出现了多少次“社会”吗？请输入“是”或“否”：')#问题（三）
      if question3 == '是':#三级分支：是
         print()
         print('经统计,《自杀论》中一共出现了' + str(word_dict['社会']) + '次“社会”' +'。')
         print()
         
         print('《自杀论》中另一条重要的线索是“人性”，事实上，《自杀论》也被称作社会学版\
的“人性论”。')#著作内容简介（四）
         print()
         
         question4 = input('您想知道本书一共出现了多少次“人性”吗？请输入“是”或“否”：')#问题（四）
         if question4 == '是':#四级分支：是
            print()
            print('经统计,《自杀论》中一共出现了' + str(word_dict['人性']) + '次“人性”' +'。')
            print()
            
            print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
            #统计词频最高的十个关键词
            result_file = open(result_filename, 'w')# 新建结果文件
            result_file.write('关键词,出现次数\n')# 写入标题行
            num = 10#确定统计范围
            for i in range(num):
              word, cnt = items_list[i]
              message = str(i+1) + '. ' + word + '\t' + str(cnt)
              print(message)
              result_file.write(word + ',' + str(cnt) + '\n')
            result_file.close()# 关闭文件
            print('已写入文件：' + result_filename)#显示已写入文件
            
         elif question4 == '否':#四级分支：否
            print()
            print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
            result_file = open(result_filename, 'w')
            result_file.write('关键词,出现次数\n')
            num = 10
            for i in range(num):
              word, cnt = items_list[i]
              message = str(i+1) + '. ' + word + '\t' + str(cnt)
              print(message)
              result_file.write(word + ',' + str(cnt) + '\n')
            result_file.close() 
            print('已写入文件：' + result_filename)
            
         else:#四级分支：错误
          print('请输入正确选项！')#报错
          
      elif question3 == '否':#三级分支：否
        print()
        print('《自杀论》中另一条重要的线索是“人性”，事实上，《自杀论》也被称作社会学版\
的“人性论”。')
        print()
        
        question4 = input('您想知道本书一共出现了多少次“人性”吗？请输入“是”或“否”：')
        if question4 == '是':#四级分支：是
            print()
            print('经统计,《自杀论》中一共出现了' + str(word_dict['人性']) + '次“人性”' +'。')
            print()
            print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
            result_file = open(result_filename, 'w')
            result_file.write('关键词,出现次数\n')
            num = 10
            for i in range(num):
              word, cnt = items_list[i]
              message = str(i+1) + '. ' + word + '\t' + str(cnt)
              print(message)
              result_file.write(word + ',' + str(cnt) + '\n')
            result_file.close() 
            print('已写入文件：' + result_filename)
            
        elif question4 == '否':#四级分支：否
            print()
            print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
            result_file = open(result_filename, 'w')
            result_file.write('关键词,出现次数\n')
            num = 10
            for i in range(num):
              word, cnt = items_list[i]
              message = str(i+1) + '. ' + word + '\t' + str(cnt)
              print(message)
              result_file.write(word + ',' + str(cnt) + '\n')
            result_file.close()  
            print('已写入文件：' + result_filename)
            
        else:#四级分支：错误
         print('请输入正确选项！')
         
      else:#三级分支：错误
       print('请输入正确选项！')
       
   elif question2 == '否':#二级分支：否
       print()
       print('《自杀论》着重讨论了自杀的社会性，即“自杀作为一种社会现象”。')
       print()
       
       question3 = input('您想知道本书一共出现了多少次“社会”吗？请输入“是”或“否”：')
       print()
       if question3 == '是':#三级分支：是
        print()
        print('经统计,《自杀论》中一共出现了' + str(word_dict['社会']) + '次“社会”' +'。')
        print()
        
        print('《自杀论》中另一条重要的线索是“人性”，事实上，《自杀论》也被称作社会学版\
的“人性论”。')
        print()
        
        question4 = input('您想知道本书一共出现了多少次“人性”吗？请输入“是”或“否”：')
        if question4 == '是':#四级分支：是
           print()
           print('经统计,《自杀论》中一共出现了' + str(word_dict['人性']) + '次“人性”' +'。')
           print()
           
           print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
           result_file = open(result_filename, 'w')
           result_file.write('关键词,出现次数\n')
           num = 10
           for i in range(num):
              word, cnt = items_list[i]
              message = str(i+1) + '. ' + word + '\t' + str(cnt)
              print(message)
              result_file.write(word + ',' + str(cnt) + '\n')
           result_file.close()  
           print('已写入文件：' + result_filename)
           
        elif question4 == '否':#四级分支：否
             print()
             print('感谢您的阅读经统计，《自杀论》中出现次数最高的十个词为：')
             result_file = open(result_filename, 'w')
             result_file.write('关键词,出现次数\n')
             num = 10
             for i in range(num):
              word, cnt = items_list[i]
              message = str(i+1) + '. ' + word + '\t' + str(cnt)
              print(message)
              result_file.write(word + ',' + str(cnt) + '\n')
             result_file.close()  
             print('已写入文件：' + result_filename)
             
        else:#四级分支：错误
         print('请输入正确选项！') 
         
       elif question3 == '否':#三级分支：否
            print()
            print('《自杀论》中另一条重要的线索是“人性”，事实上，《自杀论》也被称作社会学版\
的“人性论”。')
            print()
            
            question4 = input('您想知道本书一共出现了多少次“人性”吗？请输入“是”或“否”：')
            if question4 == '是':#四级分支：是
               print()
               print('经统计,《自杀论》中一共出现了' + str(word_dict['人性']) + '次“人性”' +'。')
               print()
               
               print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
               result_file = open(result_filename, 'w')
               result_file.write('关键词,出现次数\n')
               num = 10
               for i in range(num):
                 word, cnt = items_list[i]
                 message = str(i+1) + '. ' + word + '\t' + str(cnt)
                 print(message)
                 result_file.write(word + ',' + str(cnt) + '\n')
               result_file.close()  
               print('已写入文件：' + result_filename)
               
            elif question4 == '否':#四级分支：否
               print()
               print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
               result_file = open(result_filename, 'w')
               result_file.write('关键词,出现次数\n')
               num = 10
               for i in range(num):
                 word, cnt = items_list[i]
                 message = str(i+1) + '. ' + word + '\t' + str(cnt)
                 print(message)
                 result_file.write(word + ',' + str(cnt) + '\n')
               result_file.close()  
               print('已写入文件：' + result_filename)
               
            else:#四级分支：错误
             print('请输入正确选项！')
             
       else:#三级分支：错误
        print('请输入正确选项！')
        
   else:#二级分支：错误
       print('请输入正确选项！')
       
elif question1 == '否':#一级分支：否
    print()
    print('《自杀论》着重讨论了自杀的社会性，即“自杀作为一种社会现象”。')
    print()
    
    question3 = input('您想知道本书一共出现了多少次“社会”吗？请输入“是”或“否”：')
    if question3 == '是':#二级分支：是
        print()
        print('经统计,《自杀论》中一共出现了' + str(word_dict['社会']) + '次“社会”' +'。')
        print()
        
        print('《自杀论》中另一条重要的线索是“人性”，事实上，《自杀论》也被称作社会学版\
的“人性论”。')
        print()
        
        question4 = input('您想知道本书一共出现了多少次“人性”吗？请输入“是”或“否”：')
        if question4 == '是':#三级分支：是
            print()
            print('经统计,《自杀论》中一共出现了' + str(word_dict['人性']) + '次“人性”' +'。')
            print()
            
            print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
            result_file = open(result_filename, 'w')
            result_file.write('关键词,出现次数\n')
            num = 10
            for i in range(num):
              word, cnt = items_list[i]
              message = str(i+1) + '. ' + word + '\t' + str(cnt)
              print(message)
              result_file.write(word + ',' + str(cnt) + '\n')
            result_file.close()  
            print('已写入文件：' + result_filename)
            
        elif question4 == '否':#三级分支：否
            print()
            print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
            result_file = open(result_filename, 'w')
            result_file.write('关键词,出现次数\n')
            num = 10
            for i in range(num):
              word, cnt = items_list[i]
              message = str(i+1) + '. ' + word + '\t' + str(cnt)
              print(message)
              result_file.write(word + ',' + str(cnt) + '\n')
            result_file.close()  
            print('已写入文件：' + result_filename)
            
        else:#三级分支：错误
         print('请输入正确选项！')
         
    elif question3 == '否':#二级分支：否
        print()
        print('《自杀论》中另一条重要的线索是“人性”，事实上，《自杀论》也被称作社会学版\
的“人性论”。')
        print()
        
        question4 = input('您想知道本书一共出现了多少次“人性”吗？请输入“是”或“否”：')
        if question4 == '是':#三级分支：是
            print()
            print('经统计,《自杀论》中一共出现了' + str(word_dict['人性']) + '次“人性”' +'。')
            print()
            
            print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
            result_file = open(result_filename, 'w')
            result_file.write('关键词,出现次数\n')
            num = 10
            for i in range(num):
              word, cnt = items_list[i]
              message = str(i+1) + '. ' + word + '\t' + str(cnt)
              print(message)
              result_file.write(word + ',' + str(cnt) + '\n')
            result_file.close()  
            print('已写入文件：' + result_filename)
            
        elif question4 == '否':#三级分支：否
            print()
            print('感谢您的阅读，经统计，《自杀论》中出现次数最高的十个词为：')
            result_file = open(result_filename, 'w')
            result_file.write('关键词,出现次数\n')
            num = 10
            for i in range(num):
              word, cnt = items_list[i]
              message = str(i+1) + '. ' + word + '\t' + str(cnt)
              print(message)
              result_file.write(word + ',' + str(cnt) + '\n')
            result_file.close()  
            print('已写入文件：' + result_filename)
            
        else:#三级分支：错误
         print('请输入正确选项！')
         
    else:#二级分支：错误
     print('请输入正确选项！')
     
else:#一级分支：错误
    print('请输入正确选项！')

"""
程序结束
"""    
       

